import os, base64, json
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime
try:
    from openai import OpenAI
except Exception:
    OpenAI = None

app = FastAPI(title="IRISQI Backend")
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_methods=['*'], allow_headers=['*'])

OPENAI_KEY = os.getenv('OPENAI_API_KEY')
client = OpenAI(api_key=OPENAI_KEY) if (OpenAI and OPENAI_KEY) else None

def b64(x): return base64.b64encode(x).decode()

def chinese_zodiac(year:int):
    animals = ["Rato","Boi","Tigre","Coelho","Dragão","Serpente","Cavalo","Cabra","Macaco","Galo","Cão","Porco"]
    try:
        return animals[(int(year)-4)%12]
    except:
        return None

@app.get("/")
def root():
    return {"status":"IRISQI backend running"}

@app.post("/analyze")
async def analyze(iris_image: UploadFile = File(...), birth_year: int = Form(None)):
    img_bytes = await iris_image.read()
    if not img_bytes or len(img_bytes) < 2000:
        raise HTTPException(status_code=400, detail="Imagem inválida ou muito pequena")
    data_uri = f"data:image/jpeg;base64,{b64(img_bytes)}"
    zodiac = chinese_zodiac(birth_year) if birth_year else None

    instruction = """Você é um especialista em Iridologia e Medicina Tradicional Chinesa.
Retorne APENAS JSON válido com os campos:
{
 "element":"Madeira|Fogo|Terra|Metal|Água",
 "yin_yang":"Yin em excesso|Yang em excesso|Equilíbrio relativo",
 "emotional_state":"texto curto",
 "recommendations": {"cha":"string","balsamo":"string","massoterapia":"string","acupoints":["ST36","LI4"]},
 "short_message":"mensagem curta (filósofo chinês)",
 "confidence": 0.0
}
NÃO inclua textos extras fora do JSON. USE SOMENTE A IMAGEM COMO BASE PARA A ANÁLISE.
"""

    if client:
        try:
            resp = client.responses.create(
                model="gpt-4o-mini-vision",
                input=[{"role":"user","content":[{"type":"input_text","text":instruction},
                                                 {"type":"input_image","image_url":data_uri}]}],
                max_output_tokens=800
            )
            text = getattr(resp, 'output_text', None) or str(resp)
        except Exception as e:
            text = json.dumps({"error":"vision request failed","detail":str(e)})
    else:
        # Demo fallback
        text = json.dumps({
            "element":"Terra",
            "yin_yang":"Equilíbrio relativo",
            "emotional_state":"calmo",
            "recommendations":{"cha":"Chá de gengibre","balsamo":"Tiger Balm Vermelho","massoterapia":"Tui Na","acupoints":["ST36","LI4"]},
            "short_message":"Pequenos hábitos criam grandes mudanças. — Confúcio",
            "confidence":0.5
        }, ensure_ascii=False)

    # Try to extract JSON object from model text
    start = text.find('{'); end = text.rfind('}')
    if start!=-1 and end!=-1 and end>start:
        try:
            parsed = json.loads(text[start:end+1])
        except:
            parsed = {"raw_text": text}
    else:
        parsed = {"raw_text": text}

    parsed['_meta'] = {"created": datetime.utcnow().isoformat()+"Z", "zodiac": zodiac}
    return parsed
