# IRISQI — Projeto Completo (Frontend + Backend)

## Estrutura
- frontend/  -> index.html, style.css, script.js
- backend/   -> FastAPI (main.py), requirements.txt

## Passos rápidos
1. Subir backend no Render.com (crie repo no GitHub e aponte para Render)
2. Publicar frontend no GitHub Pages (ou Netlify)
3. Configure OPENAI_API_KEY no serviço backend
4. Substitua em frontend/script.js a variável API pelo URL do backend

## GitHub automatic push (exemplo)
Se tiver o GitHub CLI e um repositório criado, rode:
```
git init
git add .
git commit -m "IRISQI initial commit"
gh repo create irisqi-web --public --source=. --remote=origin
git push -u origin main
```
