# IRISQI Backend

- Configure env var OPENAI_API_KEY with sua chave OpenAI.
- Rodar local: pip install -r requirements.txt
  uvicorn main:app --reload --port 8000
- Endpoint POST /analyze aceita form-data com 'iris_image' e opcional 'birth_year'
