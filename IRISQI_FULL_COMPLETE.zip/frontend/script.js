const API = ""; // replace with backend URL (e.g. https://seu-backend.onrender.com)
const cam = document.getElementById('cam');
const cv = document.getElementById('cv');
const startCamBtn = document.getElementById('startCam');
const snapBtn = document.getElementById('snapBtn');
const analyzeBtn = document.getElementById('analyzeBtn');
const irisFile = document.getElementById('irisFile');
const status = document.getElementById('status');
const result = document.getElementById('result');
const resultCard = document.getElementById('resultCard');
const birthEl = document.getElementById('birth_year');

let stream=null;
startCamBtn.onclick = async () => {
  try{
    stream = await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'}});
    cam.srcObject = stream;
    status.innerText = "Câmera ativa";
  }catch(e){ status.innerText = "Erro ao acessar câmera: "+e.message }
};

snapBtn.onclick = async () => {
  if(!stream){ status.innerText = "Inicie a câmera ou envie um arquivo."; return; }
  const ctx = cv.getContext('2d');
  cv.width = cam.videoWidth; cv.height = cam.videoHeight;
  ctx.drawImage(cam,0,0);
  // preview: convert to blob and set to file input via dataTransfer (optional)
  cv.toBlob(b => {
    const f = new File([b],"iris.jpg",{type:"image/jpeg"});
    const dt = new DataTransfer();
    dt.items.add(f);
    irisFile.files = dt.files;
    status.innerText = "Foto capturada";
  },"image/jpeg",0.9);
};

function decade(d){
  const el = birthEl;
  let y = parseInt(el.value)||2000;
  y = Math.max(1900, Math.min(2025, y + d));
  el.value = y;
}

analyzeBtn.onclick = async () => {
  if(!irisFile.files.length){ alert('Envie ou tire uma foto da íris primeiro'); return; }
  const file = irisFile.files[0];
  const birth = birthEl.value;
  const fd = new FormData();
  fd.append('iris_image', file);
  if(birth) fd.append('birth_year', birth);
  status.innerText = 'Enviando para análise...';
  analyzeBtn.disabled = true;
  try{
    const res = await fetch(API + '/analyze', { method:'POST', body: fd });
    const j = await res.json();
    result.innerText = JSON.stringify(j, null, 2);
    resultCard.style.display = 'block';
    status.innerText = 'Análise concluída';
  }catch(e){
    status.innerText = 'Erro: '+e.message;
  }finally{ analyzeBtn.disabled = false; }
};
